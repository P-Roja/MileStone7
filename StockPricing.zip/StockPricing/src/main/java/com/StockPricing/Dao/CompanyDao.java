package com.StockPricing.Dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;

import com.StockPricing.model.Company;
import com.StockPricing.model.IPODetails;

public interface CompanyDao extends JpaRepository<Company, Integer> {
	public List<Company> findBySectorId(int sectorId);

	@Query("select c.companyCode from Company c where c.sectorId=:sectorid")
	int[] findSectorList(@Param("sectorid") int sectorid);

	@Query("select c from Company c where c.companyName like %:letter%")
	public List<Company> findBycompanyName(@Param(value = "letter") String letter);

}
