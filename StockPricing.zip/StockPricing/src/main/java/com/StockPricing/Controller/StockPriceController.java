package com.StockPricing.Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.StockPricing.model.Stock;
import com.StockPricing.model.StockExchange;
import com.StockPricing.service.CompanyService;
import com.StockPricing.service.StockExchangeService;
import com.StockPricing.service.StockPriceService;

@Controller
public class StockPriceController {
	static Logger log = Logger.getLogger(StockPriceController.class);
	@Autowired
	private StockPriceService stockPriceService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private StockExchangeService stockExchangeService;

	@RequestMapping("/insertStockPrice")
	public ModelAndView insertStockPrice(ModelMap map) throws SQLException {
		ModelAndView mav = null;
		ArrayList stockDetails, companyDetails = null;
		map.addAttribute("stockPrice", new Stock());
		try {
			stockDetails = (ArrayList) stockExchangeService.getStockExchangeList();
			companyDetails = (ArrayList) companyService.getCompanyList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("stockExchangeList", stockDetails);

		map.addAttribute("companyList", companyDetails);

		mav = new ModelAndView("InsertStock");
		return mav;

	}

	@RequestMapping(value = "/insertStockPrice", method = RequestMethod.POST)
	public ModelAndView insertStockPriceDetails(@ModelAttribute("stockPrice") @Valid Stock stockPrice,
			BindingResult result, HttpServletRequest request, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		ArrayList stockDetails, companyDetails, stockPriceDetails = null;
		if (result.hasErrors()) {
			try {
				stockDetails = (ArrayList) stockExchangeService.getStockExchangeList();
				companyDetails = (ArrayList) companyService.getCompanyList();
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				mav = new ModelAndView("ApplicationError");
				return mav;
			}
			map.addAttribute("stockExchangeList", stockDetails);

			map.addAttribute("companyList", companyDetails);

			mav = new ModelAndView("InsertStock");
			return mav;
		}
		try {
			stockPriceService.insertStockPrice(stockPrice);
			stockPriceDetails = (ArrayList) stockPriceService.getStockPriceList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("stockPriceList", stockPriceDetails);
		mav = new ModelAndView("StockPriceList");
		return mav;

	}

	@RequestMapping(path = "/stockPriceList")
	public ModelAndView getStockPriceList(ModelMap map) throws Exception {
		ModelAndView mav = new ModelAndView();
		ArrayList stockPriceDetails = (ArrayList) stockPriceService.getStockPriceList();
		map.addAttribute("stockPriceList", stockPriceDetails);
		mav = new ModelAndView("StockPriceList");
		return mav;
	}
	
	
	
	
}
