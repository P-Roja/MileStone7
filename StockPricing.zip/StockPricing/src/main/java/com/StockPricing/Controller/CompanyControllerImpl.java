package com.StockPricing.Controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.StockPricing.model.Company;
import com.StockPricing.model.User;
import com.StockPricing.service.CompanyService;
import com.StockPricing.service.SectorService;

@RestController
public class CompanyControllerImpl {
	
	static Logger log = Logger.getLogger(CompanyControllerImpl.class);
	@Autowired
	private CompanyService companyService;
	@Autowired
	SectorService sectorService;

	@GetMapping("/registerCompany")
	public ModelAndView insertCompany(ModelMap map) throws SQLException {
		ModelAndView mav = null;
		ArrayList sectorDetails = null;
		map.addAttribute("company", new Company());
		try {
			sectorDetails = (ArrayList) sectorService.getSectorList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("sectorList", sectorDetails);
		mav = new ModelAndView("CompanyRegistration");
		return mav;

	}

	/*
	 * @RequestMapping("/registerCompany") public ModelAndView
	 * insertCompany(ModelMap map) throws SQLException { ModelAndView mav =
	 * null; map.addAttribute("company", new Company()); ArrayList sectorDetails
	 * =(ArrayList) companyService.getSectorList();
	 * map.addAttribute("sectorList",sectorDetails); mav = new
	 * ModelAndView("CompanyRegistration"); return mav;
	 * 
	 * }
	 */

	@RequestMapping("/loginAdmin")
	public ModelAndView loginAdmin(ModelMap map) {
		ModelAndView mav = null;
		map.addAttribute("user", new User());
		mav = new ModelAndView("Login");
		return mav;

	}

	@RequestMapping(value = "/registerCompany", method = RequestMethod.POST)
	public ModelAndView registerCompany(@ModelAttribute("company") @Valid Company company, BindingResult result,
			HttpServletRequest request, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		ArrayList companyDetails, sectorDetails = null;
		if (result.hasErrors()) {
			try {
				sectorDetails = (ArrayList) sectorService.getSectorList();
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				mav = new ModelAndView("ApplicationError");
				return mav;
			}

			map.addAttribute("sectorList", sectorDetails);
			mav = new ModelAndView("CompanyRegistration");
			return mav;
		}
		try {
			companyService.insertCompany(company);
			companyDetails = (ArrayList) companyService.getCompanyList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}

		map.addAttribute("companyList", companyDetails);
		mav = new ModelAndView("ManageCompany");
		return mav;

	}

	@RequestMapping("/companyUpdate")
	public ModelAndView companyUpdation(@RequestParam("id") int companyId, ModelMap map, HttpServletRequest request,
			@ModelAttribute("company") Company company) throws ClassNotFoundException, SQLException {
		ModelAndView mav = null;
		ArrayList sectorDetails = null;
		try {
			company = companyService.fetchStockUpdate(companyId);
			sectorDetails = (ArrayList) sectorService.getSectorList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("sectorList", sectorDetails);
		map.addAttribute("update", company);
		mav = new ModelAndView("CompanyUpdate");
		return mav;

	}
	

	@RequestMapping("/companyDelete")
	public ModelAndView companyDelete(@RequestParam("id") int companyId, ModelMap map, HttpServletRequest request,
			@ModelAttribute("company") Company company) throws ClassNotFoundException, SQLException {
		ModelAndView mav = null;
		ArrayList companyDetails = null;
		try {
			 companyService.deleteCompany(companyId);
			 companyDetails = (ArrayList) companyService.getCompanyList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("companyList", companyDetails);
		mav = new ModelAndView("ManageCompany");
		return mav;
	

	}

	@RequestMapping(path = "/companyList")
	public ModelAndView getCompanyList() throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ManageCompany");
		mv.addObject("companyList", companyService.getCompanyList());
		return mv;
	}

	@RequestMapping("/importData")
	public ModelAndView adminRegistration(ModelMap map) {
		ModelAndView mav = null;
		mav = new ModelAndView("UserRegistration");
		return mav;
	}

	@RequestMapping(value = "/updateCompany", method = RequestMethod.POST)
	public ModelAndView updateCompany(HttpServletRequest request, ModelMap map,
			@ModelAttribute("company") Company company, BindingResult result)
			throws ClassNotFoundException, SQLException {

		ModelAndView mav = null;
		ArrayList companyDetails = null;
		int companyId = company.getCompanyCode();
		if (result.hasErrors()) {
			Company company1 = new Company();
			try {
				company1 = companyService.fetchStockUpdate(companyId);
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				mav = new ModelAndView("ApplicationError");
				return mav;
			}
			map.addAttribute("update", company1);
			mav = new ModelAndView("CompanyUpdate");
			return mav;
		}
		try {
			companyService.updateCompany(company);
			companyDetails = (ArrayList) companyService.getCompanyList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("companyList", companyDetails);
		mav = new ModelAndView("ManageCompany");
		return mav;

	}

}
