package com.StockPricing.Controller;

import java.sql.SQLException;
import java.util.ArrayList;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.StockPricing.model.Company;
import com.StockPricing.model.IPODetails;
import com.StockPricing.model.Sector;
import com.StockPricing.service.CompanyService;
import com.StockPricing.service.IPOService;
import com.StockPricing.service.SectorService;
import com.StockPricing.service.StockExchangeService;

@RestController
public class IPOController {
	static Logger log = Logger.getLogger(IPOController.class);
	@Autowired
	private IPOService ipoService;
	@Autowired
	private CompanyService companyService;
	@Autowired
	private StockExchangeService stockExchangeService;

	@RequestMapping("/insertIpo")
	public ModelAndView insertIPO(ModelMap map, ModelMap map1) throws SQLException {
		ModelAndView mav = null;
		ArrayList companyDetails, stockExchangeDetails = null;
		map.addAttribute("ipo", new IPODetails());
		try {
			companyDetails = (ArrayList) companyService.getCompanyList();
			stockExchangeDetails = (ArrayList) stockExchangeService.getStockExchangeList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}

		map.addAttribute("companyList", companyDetails);

		map.addAttribute("stockList", stockExchangeDetails);
		mav = new ModelAndView("IPOInsert");
		return mav;

	}

	@RequestMapping(path = "/insertIpo", method = RequestMethod.POST)
	public ModelAndView insertIpoDetails(@Valid @ModelAttribute("ipo") IPODetails ipoDetails, BindingResult result,
			HttpServletRequest request, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		ArrayList companyDetails, stockExchangeDetails, ipoDetailsList = null;
		if (result.hasErrors()) {
			try {
				companyDetails = (ArrayList) companyService.getCompanyList();
				stockExchangeDetails = (ArrayList) stockExchangeService.getStockExchangeList();
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				mav = new ModelAndView("ApplicationError");
				return mav;
			}
			map.addAttribute("companyList", companyDetails);

			map.addAttribute("stockList", stockExchangeDetails);
			mav = new ModelAndView("IPOInsert");
		}
		try {
			ipoService.insertIPO(ipoDetails);
			ipoDetailsList = (ArrayList) ipoService.getIPOList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("ipoList", ipoDetailsList);
		mav = new ModelAndView("IPOList");
		return mav;

	}

	@RequestMapping(path = "/ipoList")
	public ModelAndView getIpoList(ModelMap map) throws Exception {
		ModelAndView mav = new ModelAndView();
		ArrayList ipoDetailsList = (ArrayList) ipoService.getIPOList();
		map.addAttribute("ipoList", ipoDetailsList);
		mav = new ModelAndView("IPOList");
		return mav;
	}

	@RequestMapping(path = "/ipoUserList")
	public ModelAndView getIpoUserList(ModelMap map) throws Exception {
		ModelAndView mav = new ModelAndView();
		ArrayList ipoDetailsList = (ArrayList) ipoService.getIPOList();
		map.addAttribute("ipoList", ipoDetailsList);
		mav = new ModelAndView("IPOUser");
		return mav;
	}

	@RequestMapping("/ipoUpdate")
	public ModelAndView ipoUpdation(@RequestParam("id") int ipoId, ModelMap map, ModelMap map1,
			HttpServletRequest request, @ModelAttribute("ipo") IPODetails ipoDetails)
			throws ClassNotFoundException, SQLException {
		ModelAndView mav = null;
		ArrayList companyDetails, stockExchangeDetails = null;
		try {
			ipoDetails = ipoService.fetchUpdate(ipoId);
			companyDetails = (ArrayList) companyService.getCompanyList();
			stockExchangeDetails = (ArrayList) stockExchangeService.getStockExchangeList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("update", ipoDetails);

		map.addAttribute("companyList", companyDetails);

		map1.addAttribute("stockList", stockExchangeDetails);
		mav = new ModelAndView("IPOUpdate");
		return mav;

	}

	@RequestMapping(value = "/updateIpo", method = RequestMethod.POST)
	public ModelAndView updateIPOy(HttpServletRequest request, ModelMap map,
			@ModelAttribute("ipo") IPODetails ipoDetails, BindingResult result)
			throws ClassNotFoundException, SQLException {
		ArrayList ipoDetailsList = null;
		ModelAndView mav = null;

		int ipoId = ipoDetails.getIpoId();
		if (result.hasErrors()) {
			IPODetails ipoDetails1 = new IPODetails();
			try {
				ipoDetails1 = ipoService.fetchUpdate(ipoId);
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				mav = new ModelAndView("ApplicationError");
				return mav;
			}
			map.addAttribute("update", ipoDetails1);
			mav = new ModelAndView("IPOUpdate");
			return mav;
		}
		try {
			ipoService.updateIPODetails(ipoDetails);
			ipoDetailsList = (ArrayList) ipoService.getIPOList();
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			mav = new ModelAndView("ApplicationError");
			return mav;
		}
		map.addAttribute("ipoList", ipoDetailsList);
		mav = new ModelAndView("IPOList");
		return mav;

	}

}
