package com.StockPricing.Controller;

public class ApplicationException extends Exception {
	int errorCode;
	String errorMessage;

	public ApplicationException(String errorMessage) {

		this.errorMessage = errorMessage;
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return (errorCode + ":" + errorMessage);
	}

}
