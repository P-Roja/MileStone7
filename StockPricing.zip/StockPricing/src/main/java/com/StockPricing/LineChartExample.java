package com.StockPricing;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;  
import javax.swing.SwingUtilities;  
import javax.swing.WindowConstants;  
import org.jfree.chart.ChartFactory;  
import org.jfree.chart.ChartPanel;  
import org.jfree.chart.JFreeChart;  
import org.jfree.chart.plot.XYPlot;  
import org.jfree.data.time.Day;  
import org.jfree.data.time.TimeSeries;  
import org.jfree.data.time.TimeSeriesCollection;  
import org.jfree.data.xy.XYDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.StockPricing.service.StockPriceService; 
@Controller
public class LineChartExample extends JFrame {  
		@Autowired
		private StockPriceService stockPriceService;

  private static final long serialVersionUID = 1L; 
  public LineChartExample(String title) {  
    super(title);  
    // Create dataset  
    XYDataset dataset = createDataset();  
    // Create chart  
    JFreeChart chart = ChartFactory.createTimeSeriesChart(  
        "Stock Chart Example", // Chart  
        "Date", // X-Axis Label  
        "Price", // Y-Axis Label  
        dataset, rootPaneCheckingEnabled, rootPaneCheckingEnabled, rootPaneCheckingEnabled);  
  
    //Changes background color  
    XYPlot plot = (XYPlot)chart.getPlot();  
    plot.setBackgroundPaint(new Color(223,180,196));  
      
    ChartPanel panel = new ChartPanel(chart);  
    setContentPane(panel);  
  }  
  
  private XYDataset createDataset() {  
    TimeSeriesCollection dataset = new TimeSeriesCollection();  
  
    TimeSeries series1 = new TimeSeries("Series1");  
    series1.add(new Day(1, 1, 2019), 1900);  
    series1.add(new Day(2, 1, 2019), 97876);  
    series1.add(new Day(17, 8, 2019), 4532);  
    series1.add(new Day(12, 8, 2019), 30341);  
    series1.add(new Day(24, 8, 2019), 5023);  
    series1.add(new Day(12, 7, 2019), 45397);  
    series1.add(new Day(19, 8, 2019), 6230);  
    series1.add(new Day(21, 8, 2019), 9745);  
    series1.add(new Day(27, 8, 2019), 88955);  
    series1.add(new Day(22, 8, 2019), 23448);   
    dataset.addSeries(series1);  
  
   
      
  
    return dataset;  
  }  
  
  public static void main(String[] args) {  
    SwingUtilities.invokeLater(() -> {  
     LineChartExample example = new LineChartExample("Stock Chart");  
      example.setSize(800, 400);  
      example.setLocationRelativeTo(null);  
      example.setVisible(true);  
      example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
    });  
  }  
}  
  