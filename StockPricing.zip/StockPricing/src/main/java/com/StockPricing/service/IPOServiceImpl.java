package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.IPODetailsDao;
import com.StockPricing.model.IPODetails;

@Service
public class IPOServiceImpl implements IPOService {

	@Autowired
	IPODetailsDao ipoDao;

	@Override
	public List<IPODetails> getIPOList() throws SQLException, ApplicationException {
		try {
			return ipoDao.findAll();
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public void insertIPO(IPODetails ipoDetails) throws SQLException, ApplicationException {
		try {
			ipoDao.save(ipoDetails);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public void updateIPODetails(IPODetails ipoDetails) throws SQLException, ApplicationException {
		try {
			ipoDao.save(ipoDetails);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}

	}

	@Override
	public IPODetails fetchUpdate(int IPOId) throws SQLException, ClassNotFoundException, ApplicationException {
		try {
			return ipoDao.getOne(IPOId);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

}
