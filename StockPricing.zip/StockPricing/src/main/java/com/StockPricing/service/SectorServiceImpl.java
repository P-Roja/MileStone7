package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.SectorDao;
import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;

@Service
public class SectorServiceImpl implements SectorService {
	@Autowired
	SectorDao sectorDao;

	@Override
	public List<Sector> getSectorList() throws SQLException, ApplicationException {
		try {
			return sectorDao.findAll();
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public void insertSector(Sector sector) throws SQLException, ApplicationException {
		try {
			sectorDao.save(sector);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}

	}

	@Override
	public void updateSector(Sector sector) throws SQLException, ApplicationException {
		try {
			sectorDao.save(sector);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}

	}

	@Override
	public Sector fetchSectorUpdate(int sectorId) throws SQLException, ClassNotFoundException, ApplicationException {
		try {
			return sectorDao.findOne(sectorId);
		} catch (HibernateException he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

}
