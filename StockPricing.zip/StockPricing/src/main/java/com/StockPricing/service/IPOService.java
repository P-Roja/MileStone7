package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.model.IPODetails;
import com.StockPricing.model.Sector;

public interface IPOService {
	public List<IPODetails> getIPOList() throws SQLException, ApplicationException;

	public void insertIPO(IPODetails ipoDetails) throws SQLException, ApplicationException;

	public void updateIPODetails(IPODetails ipoDetails) throws SQLException, ApplicationException;

	public IPODetails fetchUpdate(int IPOId) throws SQLException, ClassNotFoundException, ApplicationException;

}
