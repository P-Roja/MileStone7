package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.StockExchangeDao;
import com.StockPricing.Dao.StockPriceDao;
import com.StockPricing.model.Stock;

@Service
public class StockPriceServiceImpl implements StockPriceService {
	@Autowired
	private StockPriceDao stockPriceDao;

	@Override
	public void insertStockPrice(Stock stockPrice) throws SQLException, ApplicationException {
		try {
			stockPriceDao.save(stockPrice);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public Stock updateStockPrice(Stock stockPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Stock> getStockPriceList() {
		return stockPriceDao.findAll();
		/*try {
			return stockPriceDao.findAll();
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}*/
	}

}
