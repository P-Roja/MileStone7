package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.model.User;

public interface UserService {
	public void registerUser(User user) throws  ApplicationException;

	public List<User> findByUsername(String username) throws ApplicationException;

}
