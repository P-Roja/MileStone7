package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.CompanyDao;
import com.StockPricing.Dao.SectorDao;
import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private SectorDao sectorDao;

	@Override
	public void insertCompany(Company company) throws SQLException,  ApplicationException {
		try {
			companyDao.save(company);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}

		// companyDao.insertCompany(company);
	}

	@Override
	public void updateCompany(Company company) throws SQLException, ApplicationException {
		try {
			companyDao.save(company);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public List<Company> getCompanyList() throws SQLException, ApplicationException {
		try {
			return companyDao.findAll();
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public Company fetchStockUpdate(int companyId) throws ApplicationException {
		try {
			return companyDao.getOne(companyId);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public void deleteCompany(int company) throws SQLException, ApplicationException {
		companyDao.delete(company);
		
	}

}