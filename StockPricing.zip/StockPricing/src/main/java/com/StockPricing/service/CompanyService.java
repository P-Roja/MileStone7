package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;

public interface CompanyService {

	public void insertCompany(Company company) throws SQLException, ApplicationException;

	public void updateCompany(Company company) throws SQLException, ApplicationException;
	public void deleteCompany(int company) throws SQLException, ApplicationException;

	public List<Company> getCompanyList() throws SQLException, ApplicationException;

	public Company fetchStockUpdate(int companyId) throws SQLException, ClassNotFoundException, ApplicationException;

}