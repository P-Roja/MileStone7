package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.model.Company;
import com.StockPricing.model.StockExchange;

public interface StockExchangeService {
	public void insertStock(StockExchange stockExchange) throws SQLException, ApplicationException;

	public StockExchange updateStockExchange(StockExchange stockExchange);

	public List<StockExchange> getStockExchangeList() throws SQLException,ApplicationException;

}
