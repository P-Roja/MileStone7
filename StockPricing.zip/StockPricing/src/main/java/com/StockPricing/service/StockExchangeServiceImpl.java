package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.CompanyDao;
import com.StockPricing.Dao.StockExchangeDao;
import com.StockPricing.model.StockExchange;

@Service
public class StockExchangeServiceImpl implements StockExchangeService {
	@Autowired
	private StockExchangeDao stockExchangeDao;

	@Override
	public void insertStock(StockExchange stockExchange) throws SQLException, ApplicationException {
		try {
			stockExchangeDao.save(stockExchange);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}

	}

	@Override
	public StockExchange updateStockExchange(StockExchange stockExchange) {
		return null;
	}

	@Override
	public List<StockExchange> getStockExchangeList() throws SQLException, ApplicationException {
		try {
			return stockExchangeDao.findAll();
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

}
