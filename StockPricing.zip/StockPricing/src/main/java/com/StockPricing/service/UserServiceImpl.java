package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Controller.ApplicationException;
import com.StockPricing.Dao.UserDao;

import com.StockPricing.model.User;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;

	@Override
	public void registerUser(User user) throws ApplicationException {
		try {
			userDao.save(user);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	@Override
	public List<User> findByUsername(String username) throws ApplicationException {
		try {

			return userDao.findByUsername(username);
		} catch (Exception he) {
			ApplicationException ae = new ApplicationException(he.getMessage());
			throw ae;
		}
	}

	/*
	 * @Override public boolean loginUser(User user) throws SQLException {
	 * return userDao.get }
	 */

}
