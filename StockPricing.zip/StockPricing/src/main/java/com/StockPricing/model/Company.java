package com.StockPricing.model;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "company")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "company_code")
	private int companyCode;
 
	@NotEmpty(message="Please enter company name")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Company Name should not contain numbers")
	@Size(max = 50, message = "Company Name should not exceed 50 characters")

	@Column(name = "company_name")
	private String companyName;

	@NotNull(message="please enter turn over")
	@Column(name = "turnover")
	private BigDecimal turnover;

	@NotEmpty(message="please enter CEO name")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "CEO Name should not contain numbers")
	@Size(max = 50, message = "CEO Name should  not exceed 50 characters")

	
	@Column(name = "ceo")
	private String ceo;

	@Column(name = "board_of_director")

	@NotEmpty(message="please enter board of director name")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Board Of Directors Name should not contain numbers")
	@Size(max = 50, message = "Board Of Directors Name should  not exceed 50 characters")
	private String boardOfDirectors;
	/*
	 * @ManyToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="sector_id") private Sector sector;
	 */
	@Column(name = "sector_id")
	@NotNull(message="please select sector id")
		private int sectorId;
	
	
	@NotEmpty(message="please enter brief write up")
	@Column(name = "brief_writeup")
	@Size(max = 200, message = "WriteUp  should  not exceed 200 characters")
	private String writeUp;

	@Column(name = "stock_code")
	private int stockCode;

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

/*	public double getTurnover() {
		return turnover;
	}

	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}*/

	public String getCeo() {
		return ceo;
	}

	public BigDecimal getTurnover() {
		return turnover;
	}

	public void setTurnover(BigDecimal turnover) {
		this.turnover = turnover;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

	public String getWriteUp() {
		return writeUp;
	}

	public void setWriteUp(String writeUp) {
		this.writeUp = writeUp;
	}

	public int getSectorId() {
		return sectorId;
	}

	public void setSectorId(int sectorId) {
		this.sectorId = sectorId;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}

	@Override
	public String toString() {
		return "Company [companyCode=" + companyCode + ", companyName=" + companyName + ", turnover=" + turnover
				+ ", ceo=" + ceo + ", boardOfDirectors=" + boardOfDirectors + ", sectorId=" + sectorId + ", writeUp="
				+ writeUp + ", stockCode=" + stockCode + "]";
	}

	/*
	 * @Override public String toString() { return "Company [companyCode=" +
	 * companyCode + ", companyName=" + companyName + ", turnover=" + turnover +
	 * ", ceo=" + ceo + ", boardOfDirectors=" + boardOfDirectors + ", sector=" +
	 * sector + ", writeUp=" + writeUp + ", stockCode=" + stockCode + "]"; }
	 */

	/*
	 * public Sector getSector() { return sector; }
	 * 
	 * public void setSector(Sector sector) { this.sector = sector; }
	 * 
	 * 
	 */
	/*
	 * 
	 * /* public int getStockCode() { return stockCode; }
	 * 
	 * public void setStockCode(int stockCode) { this.stockCode = stockCode; }
	 */

}
