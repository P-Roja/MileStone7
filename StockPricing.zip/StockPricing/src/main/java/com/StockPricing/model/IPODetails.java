package com.StockPricing.model;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "ipo_planned")
public class IPODetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ipo_id")
	private int ipoId;

	/*
	 * @OneToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="company_code") private Company company;
	 */

	@NotNull(message="please select company code")
	@Column(name = "company_code")
	private int companyCode;
	@NotNull(message="please select stock exchange code")
	@Column(name = "Stockexchange_code")
	private int stockExchange;

	@NotNull(message="please enter price ")
	@Column(name = "price_per_share")
	private BigDecimal priceperShare;

	@NotEmpty(message="please enter remarks")
	@Column(name = "remarks")
	private String remarks;

	@NotNull(message ="please enter total no of shares")
	@Column(name = "total_no_of_shares")

	private int totalShares;
 
	@NotNull
	@Column(name = "open_date_time")

	private Date openDateTime;

	public int getIpoId() {
		return ipoId;
	}

	public void setIpoId(int ipoId) {
		this.ipoId = ipoId;
	}

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public int getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(int stockExchange) {
		this.stockExchange = stockExchange;
	}

	public int getTotalShares() {
		return totalShares;
	}

	public void setTotalShares(int totalShares) {
		this.totalShares = totalShares;
	}

	public Date getOpenDateTime() {
		return openDateTime;
	}

	public void setOpenDateTime(Date openDateTime) {
		this.openDateTime = openDateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
/*
	public double getPriceperShare() {
		return priceperShare;
	}

	public void setPriceperShare(double priceperShare) {
		this.priceperShare = priceperShare;
	}*/

	@Override
	public String toString() {
		return "IPODetails [ipoId=" + ipoId + ", companyCode=" + companyCode + ", stockExchange=" + stockExchange
				+ ", priceperShare=" + priceperShare + ", remarks=" + remarks + ", totalShares=" + totalShares
				+ ", openDateTime=" + openDateTime + "]";
	}

	public BigDecimal getPriceperShare() {
		return priceperShare;
	}

	public void setPriceperShare(BigDecimal priceperShare) {
		this.priceperShare = priceperShare;
	}

	/*
	 * @Override public String toString() { return "IPODetails [ipoId=" + ipoId
	 * + ", company=" + company + ", stockExchange=" + stockExchange +
	 * ", priceperShare=" + priceperShare + ", remarks=" + remarks +
	 * ", totalShares=" + totalShares + ", openDateTime=" + openDateTime + "]";
	 * }
	 */
	/*
	 * public Company getCompany() { return company; }
	 * 
	 * public void setCompany(Company company) { this.company = company; }
	 */

}
